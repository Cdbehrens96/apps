#include "whiteFlash.h"

whiteFlash::whiteFlash() {

}

void whiteFlash::setup() {
	hit = false;
	phone.loadImage("LL.jpg");
}

void whiteFlash::update() {
	
}

void whiteFlash::draw() {
	if (hit == true) {
		phone.draw(100, 100);
	}
}

void whiteFlash::_keyPressed(int _key) {
	if (_key == 'z') {
		hit = true;
		ofSleepMillis(4000);
		hit = false;
	}
}