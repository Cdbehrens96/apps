#pragma once
#include "ofMain.h"

class whiteFlash {
public:


	void setup() {
		ofAddListener(ofEvents.keyPressed, this, &whiteFlash::_keyPressed);
	}
	void update();
	void draw();
	void _keyPressed(int _key);

	whiteFlash();

	ofImage phone;

	bool hit = false;

};